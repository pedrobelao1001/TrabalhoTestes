package entity;

public class Login {

}
