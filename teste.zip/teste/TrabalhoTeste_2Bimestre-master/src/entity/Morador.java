package entity;

public class Morador {

}
