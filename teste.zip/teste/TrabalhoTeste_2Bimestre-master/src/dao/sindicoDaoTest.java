//Greici Souza - RA: 2019102652
//Willian Cavalcante - RA:
//Ricardo Venancio - RA: 2019100619
//Pedro Cordeiro - RA: 2019101365


package dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import entity.Sindico;

public class sindicoDaoTest {

	@Test
	public void testInserir() {
		//Arrange
		sindicoDao sindico = new sindicoDao();
		boolean b;
		//Act
		b = sindico.inserir(null);
		//Assert
		Assert.assertFalse(b);
	}

	@Test
	public void testAlterar() {
		// Arrange
		sindicoDao sindico = new sindicoDao();
		boolean b;
		// Act
		b = sindico.alterar(null);
		// Assert
		Assert.assertFalse(b);
	}

	@Test
	public void testDeletar() {
		// Arrange
		sindicoDao sindico = new sindicoDao();
		int b;
		// Act
		b = sindico.deletar(0);
		// Assert
		Assert.assertTrue(true);
	}
	
	@Test
	public void testIsNotEquals() {
		//Arrange
		sindicoDao sindico = new sindicoDao();
		boolean b;
		//Act
		b = sindico.inserir(null);
		//Assert
		Assert.assertNotEquals(true, sindico);
	}

	@Test
	public void testFindByIDNull() {
		//Arrange
		sindicoDao sindico = new sindicoDao();
		Sindico i;
		//Act
		i = sindico.findByID(3);
		//Assert
		Assert.assertNull(i);
	}

	@Test
	public void testFindByID() {
		//Arrange
		sindicoDao sindico = new sindicoDao();
		Sindico i;
		//Act
		i = sindico.findByID(0);
		//Assert
		Assert.assertEquals(null, i);
	}

}
