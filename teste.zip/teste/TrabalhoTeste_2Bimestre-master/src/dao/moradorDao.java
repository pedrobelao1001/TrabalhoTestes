package dao;

public class moradorDao {
	
}
