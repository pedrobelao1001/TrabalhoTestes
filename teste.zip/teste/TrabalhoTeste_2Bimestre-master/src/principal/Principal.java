package principal;

import javafx.scene.control.Button;
import javafx.stage.Stage;
import view.sindico.ControllerSindico;

public class Principal {

	public static void main(String[] args) {

		new ControllerSindico().execute();
	}

}
